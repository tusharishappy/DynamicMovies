﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Web;
using System.Web.Hosting;
using DynamicMovies.Controllers;
using DynamicMovies.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DynamicMovies.Tests.Controllers
{
    [TestClass]
    public class CategoryControllerTest
    {
        private CategoryController _CategoryController;
        public CategoryController CategoryController
        {
            get
            {
                if (_CategoryController == null)
                {
                    _CategoryController = new CategoryController();
                    _CategoryController.Request = new HttpRequestMessage();
                    _CategoryController.Configuration = new System.Web.Http.HttpConfiguration();
                }

                return _CategoryController;
            }
        }

        [TestMethod]
        public void GetAll_Category()
        {
            HttpResponseMessage httpResponseMessage = CategoryController.GetAll(null);

            Assert.IsNotNull(httpResponseMessage);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, httpResponseMessage.StatusCode);
            Assert.IsTrue(httpResponseMessage.TryGetContentValue<List<Category>>(out List<Category> listCategories));
        }

        [TestMethod]
        public void GetAll_Active_Category()
        {
            HttpResponseMessage httpResponseMessage = CategoryController.GetAll(true);

            Assert.IsNotNull(httpResponseMessage);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, httpResponseMessage.StatusCode);
            Assert.IsTrue(httpResponseMessage.TryGetContentValue<List<Category>>(out List<Category> listCategories));
        }

        [TestMethod]
        public void GetAll_InActive_Category()
        {
            HttpResponseMessage httpResponseMessage = CategoryController.GetAll(false);

            Assert.IsNotNull(httpResponseMessage);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, httpResponseMessage.StatusCode);
            Assert.IsTrue(httpResponseMessage.TryGetContentValue<List<Category>>(out List<Category> listCategories));
        }

        [TestMethod]
        public void Create()
        {
            Category category = new Category()
            {
                Id = new Random().Next(10, 5000),
                Name = "Category-" + DateTime.Now.Ticks.ToString(),
                Active = true,
                CreatedBy = 1,
                CreatedAt = DateTime.Now,
                Description = "Category-" + DateTime.Now.Ticks.ToString(),
            };

            HttpResponseMessage httpResponseMessage = CategoryController.Create(category);

            Assert.IsNotNull(httpResponseMessage);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, httpResponseMessage.StatusCode);
            Assert.IsTrue(httpResponseMessage.TryGetContentValue<int>(out int categoryId));
            Assert.IsTrue(categoryId > 0);
        }

        [TestMethod]
        public void Remove()
        {
            HttpResponseMessage httpResponseMessage = CategoryController.Remove(1);

            Assert.IsNotNull(httpResponseMessage);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, httpResponseMessage.StatusCode);
            Assert.IsTrue(httpResponseMessage.TryGetContentValue<bool>(out bool isSuccess));
            Assert.IsTrue(isSuccess);
        }
    }
}

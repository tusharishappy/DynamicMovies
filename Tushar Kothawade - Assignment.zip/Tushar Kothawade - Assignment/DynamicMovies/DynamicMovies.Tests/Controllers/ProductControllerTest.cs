﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Web;
using System.Web.Hosting;
using DynamicMovies.Controllers;
using DynamicMovies.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DynamicMovies.Tests.Controllers
{
    [TestClass]
    public class ProductControllerTest
    {
        private ProductController _ProductController;
        public ProductController ProductController
        {
            get
            {
                if (_ProductController == null)
                {
                    _ProductController = new ProductController();
                    _ProductController.Request = new HttpRequestMessage();
                    _ProductController.Configuration = new System.Web.Http.HttpConfiguration();
                }

                return _ProductController;
            }
        }

        [TestMethod]
        public void GetAll_Product()
        {
            HttpResponseMessage httpResponseMessage = ProductController.GetAll(null);

            Assert.IsNotNull(httpResponseMessage);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, httpResponseMessage.StatusCode);
            Assert.IsTrue(httpResponseMessage.TryGetContentValue<List<Product>>(out List<Product> listProducts));
        }

        [TestMethod]
        public void GetAll_Active_Product()
        {
            HttpResponseMessage httpResponseMessage = ProductController.GetAll(true);

            Assert.IsNotNull(httpResponseMessage);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, httpResponseMessage.StatusCode);
            Assert.IsTrue(httpResponseMessage.TryGetContentValue<List<Product>>(out List<Product> listProducts));
        }

        [TestMethod]
        public void GetAll_InActive_Product()
        {
            HttpResponseMessage httpResponseMessage = ProductController.GetAll(false);

            Assert.IsNotNull(httpResponseMessage);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, httpResponseMessage.StatusCode);
            Assert.IsTrue(httpResponseMessage.TryGetContentValue<List<Product>>(out List<Product> listProducts));
        }

        [TestMethod]
        public void GetAllByCategory_Product()
        {
            HttpResponseMessage httpResponseMessage = ProductController.GetAllByCategory(null);

            Assert.IsNotNull(httpResponseMessage);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, httpResponseMessage.StatusCode);
            Assert.IsTrue(httpResponseMessage.TryGetContentValue<List<CategorywiseProducts>>(out List<CategorywiseProducts> listCategorywiseProducts));
        }

        [TestMethod]
        public void Create()
        {
            Product Product = new Product()
            {
                Id = new Random().Next(10, 5000),
                CategoryId = 1,
                Name = "Movie - " + DateTime.Now.Ticks.ToString(),
                Cast = "Cast - " + DateTime.Now.Ticks.ToString(),
                Director = "Director - " + DateTime.Now.Ticks.ToString(),
                FileName = "FileName - " + DateTime.Now.Ticks.ToString() + ".mkv",
                Video = new byte[10],
                Active = true,
                CreatedBy = 1,
                CreatedAt = DateTime.Now,
                Description = "Movie-" + DateTime.Now.Ticks.ToString(),
            };

            HttpResponseMessage httpResponseMessage = ProductController.Create(Product);

            Assert.IsNotNull(httpResponseMessage);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, httpResponseMessage.StatusCode);
            Assert.IsTrue(httpResponseMessage.TryGetContentValue<int>(out int ProductId));
            Assert.IsTrue(ProductId > 0);
        }

        [TestMethod]
        public void Remove()
        {
            HttpResponseMessage httpResponseMessage = ProductController.Remove(1);

            Assert.IsNotNull(httpResponseMessage);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, httpResponseMessage.StatusCode);
            Assert.IsTrue(httpResponseMessage.TryGetContentValue<bool>(out bool isSuccess));
            Assert.IsTrue(isSuccess);
        }

        [TestMethod]
        public void UpdateVideoDescription()
        {
            HttpResponseMessage httpResponseMessage = ProductController.UpdateVideoDescription(new Models.UpdateVideoDescriptionModel() { ProductId = 1, VideoDescription = "Movie-" + DateTime.Now.Ticks.ToString() });

            Assert.IsNotNull(httpResponseMessage);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, httpResponseMessage.StatusCode);
            Assert.IsTrue(httpResponseMessage.TryGetContentValue<bool>(out bool isSucess));
            Assert.IsTrue(isSucess);
        }
    }
}

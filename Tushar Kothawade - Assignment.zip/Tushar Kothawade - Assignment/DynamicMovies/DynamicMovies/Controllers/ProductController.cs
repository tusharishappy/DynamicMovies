﻿using DynamicMovies.Common;
using DynamicMovies.DataAccess;
using DynamicMovies.Entities;
using DynamicMovies.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace DynamicMovies.Controllers
{
    /// <summary>
    /// PRODUCT API
    /// </summary>
    [DMExceptionFilter]
    [DMModelValidator]
    public class ProductController : ApiController
    {
        /// <summary>
        /// NEW PRODUCT CREATION API
        /// </summary>
        /// <param name="Product">PRODUCT INPUT PARAMATER</param>
        /// <returns>UNIQUE PRODUCT ID</returns>
        [HttpPost]
        [DMAuthorization(new Enums.Role[] { Enums.Role.Admin })]
        public HttpResponseMessage Create([FromBody]Product Product)
        {
            HttpResponseMessage response = null;

            int ProductId = ProductDataAccess.Create(Product);

            if (ProductId > 0)
            {
                response = Request.CreateResponse(HttpStatusCode.OK, ProductId);
            }
            else
            {
                throw new Exception(Resource.ErrorMessage_Product_Create_Failed);
            }

            return response;
        }

        /// <summary>
        /// UPDATEVIDEODESCRIPTION PRODUCT API
        /// </summary>
        /// <param name="productId">PRODUCT ID TO UPDATE</param>
        /// <param name="videoDescription">VIDEODESCRIPTION TO UPDATE</param>
        /// <returns>SUCCESSFULL FLAG</returns>
        [HttpPut]
        [DMAuthorization(new Enums.Role[] { Enums.Role.Admin })]
        public HttpResponseMessage UpdateVideoDescription([FromBody]Models.UpdateVideoDescriptionModel updateVideoDescriptionModel)
        {
            if (updateVideoDescriptionModel != null && updateVideoDescriptionModel.ProductId > 0)
            {
                return Request.CreateResponse(HttpStatusCode.OK, ProductDataAccess.UpdateVideoDescription(updateVideoDescriptionModel.ProductId, updateVideoDescriptionModel.VideoDescription));
            }
            else
            {
                throw new Exception(Resource.ErrorMessage_Product_Update_VideoDescription_Failed);
            }
        }

        /// <summary>
        /// REMOVE Product API
        /// </summary>
        /// <param name="productId">Product ID TO REMOVE</param>
        /// <returns>SUCCESSFULL FLAG</returns>
        [HttpDelete]
        [DMAuthorization(new Enums.Role[] { Enums.Role.Admin })]
        public HttpResponseMessage Remove([FromUri]int productId)
        {
            if (productId > 0)
            {
                return Request.CreateResponse(HttpStatusCode.OK, ProductDataAccess.Remove(productId));
            }
            else
            {
                throw new Exception(Resource.ErrorMessage_Product_Delete_Invalid);
            }
        }

        /// <summary>
        /// GETS LIST OF ALL PRODUCTS
        /// </summary>
        /// <param name="active">ACTIVE INPUT PARAMATER</param>
        /// <returns>LIST OF CATEGORIES</returns>
        [HttpGet]
        [DMAuthorization(new Enums.Role[] { Enums.Role.Admin, Enums.Role.User })]
        public HttpResponseMessage GetAll([FromUri]bool? active)
        {
            return Request.CreateResponse(HttpStatusCode.OK, ProductDataAccess.GetAll(active));
        }

        /// <summary>
        /// GETS LIST OF VIDEO'S BY CATEGORIES
        /// </summary>
        /// <param name="active">ACTIVE INPUT PARAMATER</param>
        /// <returns>LIST OF CATEGORIES</returns>
        [HttpGet]
        [DMAuthorization(new Enums.Role[] { Enums.Role.Admin, Enums.Role.User })]
        public HttpResponseMessage GetAllByCategory([FromUri]bool? active)
        {
            return Request.CreateResponse(HttpStatusCode.OK, ProductDataAccess.GetAllByCategory(active));
        }
    }
}

﻿using DynamicMovies.Filters;
using System.Web.Mvc;

namespace DynamicMovies.Controllers
{
    [DMExceptionFilter]
    [DMModelValidator]
    [DMAuthorization]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "DynamicMovies - Home Page";

            return View();
        }
    }
}

﻿using DynamicMovies.Common;
using DynamicMovies.DataAccess;
using DynamicMovies.Entities;
using DynamicMovies.Filters;
using System;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Security;

namespace DynamicMovies.Controllers
{
    /// <summary>
    /// USER MANAGEMENT API
    /// </summary>
    [DMExceptionFilter]
    [DMModelValidator]
    public class UserController : ApiController
    {
        /// <summary>
        /// NEW USER REGISTRATION API
        /// </summary>
        /// <param name="user">USER INPUT PARAMATER</param>
        /// <returns>UNIQUE USER ID</returns>
        [HttpPost]
        public HttpResponseMessage Register([FromBody]User user)
        {
            HttpResponseMessage response = null;

            int userId = UserDataAccess.Create(user);

            if (userId > 0)
            {
                response = Request.CreateResponse(HttpStatusCode.OK, userId);
            }
            else
            {
                throw new Exception(Resource.ErrorMessage_User_Create_Failed);
            }

            return response;
        }

        /// <summary>
        /// USER LOGIN API
        /// </summary>
        /// <param name="login">LOGIN INPUT PARAMETER</param>
        /// <returns>SUCCESSFULL FLAG AND USER DETAILS</returns>
        [HttpPost]
        public HttpResponseMessage Login([FromBody]Login login)
        {
            HttpResponseMessage response = null;
            bool isAuthenticated = false;

            if (login != null && !string.IsNullOrWhiteSpace(login.UserName) && !string.IsNullOrWhiteSpace(login.Password))
            {
                User user = UserDataAccess.Login(login);

                if (user != null && user.Id > 0)
                {
                    isAuthenticated = true;
                    HttpContext.Current.Session.Add(DynamicMovies.Common.Constants.Login_User, user);

                    // SUCCESS --> CREATE NON-PERSISTENT AUTHENTICATION COOKIE.
                    FormsAuthentication.SetAuthCookie(login.UserName, true);

                    response = Request.CreateResponse(HttpStatusCode.OK, new { isAuthenticated, user });
                }
                else
                {
                    response = Request.CreateResponse(HttpStatusCode.Unauthorized, Resource.ErrorMessage_User_Login_Failed);
                }
            }
            else
            {
                throw new Exception(Resource.ErrorMessage_User_Login_Payload_Invalid);
            }

            return response;
        }

        /// <summary>
        /// LOGOUT API
        /// </summary>
        /// <returns>SUCCESSFULL FLAG</returns>
        [HttpPost]
        [DMAuthorization(new Enums.Role[] { Enums.Role.User, Enums.Role.Admin })]
        public HttpResponseMessage Logout()
        {
            FormsAuthentication.SignOut();
            HttpContext.Current.Session.Abandon();

            return Request.CreateResponse(HttpStatusCode.OK, true);
        }
    }
}

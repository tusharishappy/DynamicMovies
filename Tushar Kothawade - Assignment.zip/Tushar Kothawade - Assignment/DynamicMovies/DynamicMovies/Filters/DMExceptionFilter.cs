﻿using DynamicMovies.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http.Filters;

namespace DynamicMovies.Filters
{
    public class DMExceptionFilter : ExceptionFilterAttribute
    {
        public override void OnException(HttpActionExecutedContext actionExecutedContext)
        {
            Logger.Log(actionExecutedContext.Exception);
            HttpStatusCode httpStatusCode = HttpStatusCode.InternalServerError;

            DMException dMException = new DMException();
            dMException.ErrorCode = "TODO";
            dMException.UFErrorMessage = "Error occurred while processing your request, please contact your system administrator.";

            if (actionExecutedContext.Exception.InnerException == null)
            {
                dMException.ActualErrorMessage = actionExecutedContext.Exception.Message;
            }
            else
            {
                dMException.ActualErrorMessage = actionExecutedContext.Exception.InnerException.Message;
            }

            if (actionExecutedContext.ActionContext != null && actionExecutedContext.ActionContext.ModelState != null && !actionExecutedContext.ActionContext.ModelState.IsValid)
            {
                httpStatusCode = HttpStatusCode.BadRequest;
                List<DMValidationErrors> listDMValidationErrors = new List<DMValidationErrors>();

                dMException.DMValidationErrors = (from error in actionExecutedContext.ActionContext.ModelState
                                                  from vError in error.Value.Errors
                                                  select new DMValidationErrors()
                                                  {
                                                      ErrorCode = "TODO",
                                                      UFErrorMessage = error.Key + ":" + vError.ErrorMessage,
                                                      ActualErrorMessage = error.Key + ":" + vError.ErrorMessage,
                                                  }).ToArray();
            }

            actionExecutedContext.Response = actionExecutedContext.Request.CreateResponse<DMException>(httpStatusCode, dMException);
        }
    }
}
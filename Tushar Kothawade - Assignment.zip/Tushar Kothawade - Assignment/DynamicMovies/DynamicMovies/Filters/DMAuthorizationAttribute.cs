﻿using DynamicMovies.Common;
using DynamicMovies.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace DynamicMovies.Filters
{
    public class DMAuthorizationAttribute : AuthorizationFilterAttribute
    {
        private Enums.Role[] _Roles;
        public Enums.Role[] Roles
        {
            get { return _Roles; }
            set { _Roles = value; }
        }

        public DMAuthorizationAttribute()
        {

        }

        public DMAuthorizationAttribute(Enums.Role[] roles)
        {
            if (roles != null && roles.Length > 0)
            {
                Roles = roles;
            }
        }

        public override void OnAuthorization(HttpActionContext actionContext)
        {
            bool isAuthorized = false;

            if (Roles != null && Roles.Length > 0)
            {
                User user = HttpContext.Current.Session[DynamicMovies.Common.Constants.Login_User] as User;

                //VERIFY USER ROLE WITH ALLOWED ROLES
                if (user != null && user.Roles != null && user.Roles.Length > 0)
                {
                    Enums.Role[] matchedRoles = (from aRole in Roles
                                                 from uRole in user.Roles
                                                 where aRole == uRole
                                                 select aRole).ToArray();

                    if (matchedRoles != null && matchedRoles.Length > 0)
                    {
                        isAuthorized = true;

                        // SETTING CURRENT PRINCIPLE  
                        Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity(user.LoginUserName), null);
                    }
                }
            }

            if (!isAuthorized)
            {
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized, Resource.ErrorMessage_User_Session_Expired);
            }
        }
    }
}
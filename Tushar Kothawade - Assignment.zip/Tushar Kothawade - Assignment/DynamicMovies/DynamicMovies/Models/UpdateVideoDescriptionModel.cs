﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DynamicMovies.Models
{
    public class UpdateVideoDescriptionModel
    {
        public int ProductId { get; set; }
        public string VideoDescription { get; set; }
    }
}
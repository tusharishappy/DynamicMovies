﻿using DynamicMovies.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DynamicMovies.Entities
{
    public class CategorywiseProducts : Category
    {
        public List<Product> ListProducts { get; set; }
    }
}

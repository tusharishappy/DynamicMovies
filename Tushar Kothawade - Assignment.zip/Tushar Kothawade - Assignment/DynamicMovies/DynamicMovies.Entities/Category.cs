﻿using DynamicMovies.Common;
using System;
using System.ComponentModel.DataAnnotations;

namespace DynamicMovies.Entities
{
    public class Category : BaseEntity
    {
        [Required]
        [MaxLength(250)]
        public string Name { get; set; }
    }
}

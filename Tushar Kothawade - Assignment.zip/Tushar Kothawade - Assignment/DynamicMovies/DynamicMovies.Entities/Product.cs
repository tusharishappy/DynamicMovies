﻿using DynamicMovies.Common;
using System;
using System.ComponentModel.DataAnnotations;

namespace DynamicMovies.Entities
{
    /// <summary>
    /// THIS CAN BE MOVIE, EDUCATIONAL VIDEO'S, DOCUMENTARY ETC. 
    /// </summary>
    public class Product : BaseEntity
    {
        [Required]
        [MaxLength(250)]
        public string Name { get; set; }

        [Required]
        public int CategoryId { get; set; }

        public string CategoryName { get; set; }

        [MaxLength(1000)]
        public string Cast { get; set; }

        [Required]
        public DateTime ReleaseDate { get; set; }

        [Required]
        public string Director { get; set; }

        public string FileName { get; set; }

        public byte[] Video { get; set; }

        public string VideoDescription { get; set; }
    }
}

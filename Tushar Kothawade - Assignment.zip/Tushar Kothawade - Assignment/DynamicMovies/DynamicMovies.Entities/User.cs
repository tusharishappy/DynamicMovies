﻿using DynamicMovies.Common;
using System.ComponentModel.DataAnnotations;

namespace DynamicMovies.Entities
{
    public class User : BaseEntity
    {
        [Required]
        [MaxLength(100)]
        public string FirstName { get; set; }

        [Required]
        [MaxLength(100)]
        public string LastName { get; set; }

        [Required]
        [MaxLength(250)]
        public string Address { get; set; }

        [Required]
        [MaxLength(10)]
        public string MobileNumber { get; set; }

        [Required]
        public Enums.Gender Gender { get; set; }

        [Required]
        [MaxLength(100)]
        public string LoginUserName { get; set; }

        [Required]
        [MaxLength(100)]
        public string Password { get; set; }

        [Required]
        public Enums.Role[] Roles { get; set; }
    }
}

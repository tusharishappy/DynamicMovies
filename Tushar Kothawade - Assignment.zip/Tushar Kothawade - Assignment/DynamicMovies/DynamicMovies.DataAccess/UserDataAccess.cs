﻿using DynamicMovies.Common;
using DynamicMovies.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicMovies.DataAccess
{
    /// <summary>
    /// THIS CLASS IS RESPONSIBLE TO PERFORM ALL CRUD OPERATIONS RELATED TO USER
    /// </summary>
    public class UserDataAccess
    {
        /// <summary>
        ///INMEMORY COLLECTION IS CREATED TO ACT AS DATABASE ENTITYMODEL
        /// </summary>
        private static List<User> _Users;
        public static List<User> Users
        {
            get
            {
                if (_Users == null)
                {
                    _Users = new List<User>();
                    _Users.Add(new User() { Id = 1, FirstName = "Admin", LastName = "Admin", Gender = Enums.Gender.Male, Address = "Pune", LoginUserName = "admin", Password = "admin", Roles = new Enums.Role[] { Enums.Role.Admin }, Active = true, CreatedBy = 1, CreatedAt = DateTime.Now, Description = "Admin role user" });
                    _Users.Add(new User() { Id = 2, FirstName = "User", LastName = "User", Gender = Enums.Gender.Male, Address = "Pune", LoginUserName = "user", Password = "user", Roles = new Enums.Role[] { Enums.Role.User }, Active = true, CreatedBy = 1, CreatedAt = DateTime.Now, Description = "Visitor role user" });
                }

                return _Users;
            }
            set { _Users = value; }
        }

        /// <summary>
        ///ADDS OBJECT INTO DATABASE / INMEMORY COLLECTION
        ///
        public static int Create(User user)
        {
            try
            {
                //THIS IS JUST ADDED FOR UNIQUE ID GENERATION
                //WHEN WE IMPLEMENT DATABASE IDENTITY/PRIMARYKEY BELOW LINE IS NOT NEEDED.
                user.Id = new Random().Next(Users.Max(i => i.Id), int.MaxValue);
                Users.Add(user);

                return user.Id;
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }
        }

        /// <summary>
        ///RETRIEVES SPECIFIC RECORD FROM DATABASE / INMEMORY COLLECTION
        ///
        public static User Login(Login login)
        {
            try
            {
                return Users.FirstOrDefault(i => i.LoginUserName.ToLower() == login.UserName && i.Password == login.Password);
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }
        }

        /// <summary>
        ///RETRIEVES ALL RECORDS FROM DATABASE / INMEMORY COLLECTION
        ///
        public static List<User> GetAll(bool? active)
        {
            try
            {
                return Users.Where(i => ((active == null) ? true : i.Active == active))
                            .OrderByDescending(i => i.Id)
                            .ToList();
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }
        }

        /// <summary>
        ///RETRIEVES SPECIFIC RECORD FROM DATABASE / INMEMORY COLLECTION
        ///
        public static User Get(int id)
        {
            try
            {
                return Users.FirstOrDefault(i => i.Id == id);
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }
        }

        /// <summary>
        ///REMOVES SPECIFIC RECORD FROM DATABASE / INMEMORY COLLECTION
        ///
        public static bool Remove(int id)
        {
            try
            {
                User user = Users.FirstOrDefault(i => i.Id == id);

                if (user != null)
                {
                    return Users.Remove(user);
                }
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }

            return false;
        }
    }
}

﻿using DynamicMovies.Common;
using DynamicMovies.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicMovies.DataAccess
{
    /// <summary>
    /// THIS CLASS IS RESPONSIBLE TO PERFORM ALL CRUD OPERATIONS RELATED TO CATEGORY
    /// </summary>
    public class CategoryDataAccess
    {
        /// <summary>
        ///INMEMORY COLLECTION IS CREATED TO ACT AS DATABASE ENTITYMODEL
        /// </summary>
        private static List<Category> _Categories;
        public static List<Category> Categories
        {
            get
            {
                //INMEMORY COLLECTION IS CREATED TO ACT AS DATABASE ENTITYMODEL
                if (_Categories == null)
                {
                    _Categories = new List<Category>();
                    _Categories.Add(new Category() { Id = 1, Name = "Action", Active = true, CreatedBy = 1, CreatedAt = DateTime.Now, Description = "Action Category" });
                    _Categories.Add(new Category() { Id = 2, Name = "Adventure", Active = true, CreatedBy = 1, CreatedAt = DateTime.Now, Description = "Adventure Category" });
                    _Categories.Add(new Category() { Id = 3, Name = "Comedy", Active = true, CreatedBy = 1, CreatedAt = DateTime.Now, Description = "Comedy Category" });
                    _Categories.Add(new Category() { Id = 4, Name = "Drama", Active = true, CreatedBy = 1, CreatedAt = DateTime.Now, Description = "Drama Category" });
                }

                return _Categories;
            }

            set { _Categories = value; }
        }

        /// <summary>
        ///ADDS OBJECT INTO DATABASE / INMEMORY COLLECTION
        ///
        public static int Create(Category Category)
        {
            try
            {
                //THIS IS JUST ADDED FOR UNIQUE ID GENERATION
                //WHEN WE IMPLEMENT DATABASE IDENTITY/PRIMARYKEY BELOW LINE IS NOT NEEDED.
                Category.Id = new Random().Next(Categories.Max(i => i.Id), int.MaxValue);
                Categories.Add(Category);

                return Category.Id;
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }
        }

        /// <summary>
        ///RETRIEVES ALL RECORDS FROM DATABASE / INMEMORY COLLECTION
        ///
        public static List<Category> GetAll(bool? active)
        {
            try
            {
                return Categories.Where(i => ((active == null) ? true : i.Active == active))
                                 .OrderByDescending(i => i.Id)
                                 .ToList();
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }
        }

        /// <summary>
        ///RETRIEVES SPECIFIC RECORD FROM DATABASE / INMEMORY COLLECTION
        ///
        public static Category Get(int id)
        {
            try
            {
                return Categories.FirstOrDefault(i => i.Id == id);
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }
        }

        /// <summary>
        ///REMOVES SPECIFIC RECORD FROM DATABASE / INMEMORY COLLECTION
        ///
        public static bool Remove(int id)
        {
            try
            {
                Category category = Categories.FirstOrDefault(i => i.Id == id);

                if (category != null)
                {
                    return Categories.Remove(category);
                }
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }

            return false;
        }
    }
}

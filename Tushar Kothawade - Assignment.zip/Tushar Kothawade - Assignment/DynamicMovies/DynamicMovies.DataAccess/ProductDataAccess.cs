﻿using DynamicMovies.Common;
using DynamicMovies.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicMovies.DataAccess
{
    /// <summary>
    /// THIS CLASS IS RESPONSIBLE TO PERFORM ALL CRUD OPERATIONS RELATED TO PRODUCT
    /// </summary>
    public class ProductDataAccess
    {
        /// <summary>
        ///INMEMORY COLLECTION IS CREATED TO ACT AS DATABASE ENTITYMODEL
        /// </summary>
        private static List<Product> _Products;
        public static List<Product> Products
        {
            get
            {
                //INMEMORY COLLECTION IS CREATED TO ACT AS DATABASE ENTITYMODEL
                if (_Products == null)
                {
                    _Products = new List<Product>();
                    _Products.Add(new Product() { Id = 1, CategoryId = 1, Name = "Uri: The Surgical Strike", Cast = "Vickey", Director = "Aditya Dhar", FileName = "uri.mkv", Video = null, VideoDescription = "HD PRINT", Active = true, CreatedBy = 1, CreatedAt = DateTime.Now, Description = "Movie - Uri: The Surgical Strike" });
                    _Products.Add(new Product() { Id = 2, CategoryId = 1, Name = "Sanju", Cast = "Sanju", Director = "Sanju", FileName = "sanju.mkv", Video = null, VideoDescription = "NORMAL PRINT", Active = true, CreatedBy = 1, CreatedAt = DateTime.Now, Description = "Movie - Sanju" });
                    _Products.Add(new Product() { Id = 3, CategoryId = 2, Name = "Mission Mangal", Cast = "Akshay Kumar", Director = "Akshay", FileName = "missionmangal.mkv", Video = null, VideoDescription = "UHD PRINT", Active = true, CreatedBy = 1, CreatedAt = DateTime.Now, Description = "Movie - Mission Mangal" });
                    _Products.Add(new Product() { Id = 4, CategoryId = 3, Name = "Thugs of Hindostan", Cast = "Amitabh B", Director = "Vijay Krishna Acharya", FileName = "thugsofhindostan.mkv", Video = null, VideoDescription = "HD PRINT", Active = true, CreatedBy = 1, CreatedAt = DateTime.Now, Description = "Movie - Thugs of Hindostan" });
                    _Products.Add(new Product() { Id = 5, CategoryId = 3, Name = "Saaho", Cast = "Saaho Cast", Director = "Saaho Director", FileName = "saaho.mkv", Video = null, VideoDescription = "HD PRINT", Active = true, CreatedBy = 1, CreatedAt = DateTime.Now, Description = "Movie - Saaho" });
                    _Products.Add(new Product() { Id = 6, CategoryId = 4, Name = "Dilwale", Cast = "Dilwale cast", Director = "Dilwale Director", FileName = "dilwale.mkv", Video = null, VideoDescription = "4K PRINT", Active = true, CreatedBy = 1, CreatedAt = DateTime.Now, Description = "Movie - Dilwale" });
                }

                return _Products;
            }

            set { _Products = value; }
        }

        /// <summary>
        ///ADDS OBJECT INTO DATABASE / INMEMORY COLLECTION
        ///
        public static int Create(Product Product)
        {
            try
            {
                //THIS IS JUST ADDED FOR UNIQUE ID GENERATION
                //WHEN WE IMPLEMENT DATABASE IDENTITY/PRIMARYKEY BELOW LINE IS NOT NEEDED.
                Product.Id = new Random().Next(Products.Max(i => i.Id), int.MaxValue);
                Products.Add(Product);

                return Product.Id;
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }
        }

        /// <summary>
        ///ADDS OBJECT INTO DATABASE / INMEMORY COLLECTION
        ///
        public static bool UpdateVideoDescription(int productId, string videoDescription)
        {
            bool isSuccess = false;

            try
            {
                Product product = Get(productId);

                if (product != null)
                {
                    Products.FirstOrDefault(i => i.Id == productId).VideoDescription = videoDescription;
                    isSuccess = true;
                }
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }

            return isSuccess;
        }

        /// <summary>
        ///RETRIEVES ALL RECORDS FROM DATABASE / INMEMORY COLLECTION
        ///
        public static List<Product> GetAll(bool? active)
        {
            try
            {
                return Products.Where(i => ((active == null) ? true : i.Active == active))
                                 .OrderByDescending(i => i.Id)
                                 .ToList();
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }
        }

        /// <summary>
        ///RETRIEVES ALL RECORDS BY CATEGORY FROM DATABASE / INMEMORY COLLECTION
        ///
        public static List<CategorywiseProducts> GetAllByCategory(bool? active)
        {
            List<CategorywiseProducts> listCategorywiseProducts = null;

            try
            {
                listCategorywiseProducts = Products.GroupBy(i => i.CategoryId).Select(i => i.FirstOrDefault())
                                                   .Select(i => new CategorywiseProducts() { Name = i.CategoryName, Id = i.CategoryId })
                                                   .ToList();

                if (listCategorywiseProducts != null)
                {
                    listCategorywiseProducts.ForEach(c => c.ListProducts = Products.Where(p => p.CategoryId == c.Id).ToList());
                }

                return listCategorywiseProducts;
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }
        }

        /// <summary>
        ///RETRIEVES SPECIFIC RECORD FROM DATABASE / INMEMORY COLLECTION
        ///
        public static Product Get(int id)
        {
            try
            {
                return Products.FirstOrDefault(i => i.Id == id);
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }
        }

        /// <summary>
        ///REMOVES SPECIFIC RECORD FROM DATABASE / INMEMORY COLLECTION
        ///
        public static bool Remove(int id)
        {
            try
            {
                Product Product = Products.FirstOrDefault(i => i.Id == id);

                if (Product != null)
                {
                    return Products.Remove(Product);
                }
            }
            catch (Exception exception)
            {
                Logger.Log(exception);
                throw;
            }

            return false;
        }
    }
}

﻿namespace DynamicMovies.Common
{
    public static class Config
    {

    }
}

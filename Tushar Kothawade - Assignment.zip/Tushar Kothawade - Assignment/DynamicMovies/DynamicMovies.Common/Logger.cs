﻿using System;
using System.Diagnostics;

namespace DynamicMovies.Common
{
    //ANY LOGGING API CAN BE USED TO LOG DATA EXAMPLE - LOG4NET
    public static class Logger
    {
        /// <summary>
        /// LOG EXCEPTION
        /// </summary>
        /// <param name="exception">EXCEPTION PARAMETER</param>
        /// <param name="logType">ENUMS.LOGTYPE PARAMETER</param>
        public static void Log(Enums.LogType logType, string message)
        {
            try
            {
                //CALL ANY API TO LOG DATA
            }
            catch (Exception exception)
            {
                WriteEventLog(exception);
            }
        }

        /// <summary>
        /// LOG EXCEPTION
        /// </summary>
        /// <param name="exception">EXCEPTION PARAMETER</param>
        public static void Log(Exception exception)
        {
            try
            {
                //CALL ANY API TO LOG DATA
            }
            catch (Exception sourceexception)
            {
                WriteEventLog(sourceexception);
            }
        }

        /// <summary>
        /// THIS IS USED TO LOG DATA IN WINDOWS EVENT IF ANY CONSUMED API FAILS TO LOG DATA.
        /// </summary>
        /// <param name="exception">EXCEPTION PARAMETER</param>
        private static void WriteEventLog(Exception exception)
        {
            if (!EventLog.SourceExists(Constants.AppplicationName))
                EventLog.CreateEventSource(Constants.AppplicationName, Constants.AppplicationName);

            EventLog eventLog = new EventLog(Constants.AppplicationName);
            eventLog.Source = Constants.AppplicationName;

            if (exception != null)
                eventLog.WriteEntry(exception.Message, EventLogEntryType.Error);
        }
    }
}

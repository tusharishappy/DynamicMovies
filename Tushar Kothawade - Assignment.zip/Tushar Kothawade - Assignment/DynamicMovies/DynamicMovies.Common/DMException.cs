﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicMovies.Common
{
    public class DMException
    {
        public string ErrorCode { get; set; }
        public string UFErrorMessage { get; set; }
        public string ActualErrorMessage { get; set; }
        public DMValidationErrors[] DMValidationErrors { get; set; }
    }

    public class DMValidationErrors
    {
        public string ErrorCode { get; set; }
        public string UFErrorMessage { get; set; }
        public string ActualErrorMessage { get; set; }
    }
}

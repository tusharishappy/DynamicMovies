﻿namespace DynamicMovies.Common
{
    public class Constants
    {
        public const string AppplicationName = "DynamicMovies";
        public const string Login_User = "User";
    }
}

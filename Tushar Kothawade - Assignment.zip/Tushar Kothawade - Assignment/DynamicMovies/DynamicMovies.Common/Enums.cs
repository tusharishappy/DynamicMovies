﻿namespace DynamicMovies.Common
{
    public static class Enums
    {
        public enum LogType
        {
            Error,
            Warning,
            Information,
        }

        public enum Gender
        {
            Male,
            Female,
            Other,
        }

        public enum Role
        {
            Admin,
            User,
        }
    }
}
